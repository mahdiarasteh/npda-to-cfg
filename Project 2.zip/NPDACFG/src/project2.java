import java.util.LinkedList;
import java.util.Scanner;
	
public class project2 {
	
	static void Main(String[] args)
    {
		Scanner input = new Scanner(System.in);
		
		int x = Integer.parseInt(input.next());
        
		input.next();
		
		
		LinkedList<String> stringlinkedlist = new LinkedList<String>();
		
        for (int i = 0; i < x; i++)
        {
            String grammer = "q" + i;
            stringlinkedlist.add(grammer);
        }
        
        String a = "";
        String b = "";
        
        while ((a = input.next()) != "")
        {
            NpdaToCFG N = new NpdaToCFG(a);
            
            b += N.Grammer(stringlinkedlist);
            
            b += "\n";
        }
        
        System.out.println(b);
    }
}

class NpdaToCFG {
			
	String State1 ,State2, Input1 ,Input2 ,Output ;
	boolean firststate ,laststate;
	
	public NpdaToCFG(String str)
    {
        String[] StringArray = str.split(str, ',');
        
        if (StringArray[0].charAt(0) == '-')
        {
            firststate = true;
            State1 = StringArray[0].substring(2);
        }
        else
        {
            firststate = false;
            State1 = StringArray[0];
        }
        Input1 = StringArray[1];
        Input2 = StringArray[2];
        Output = StringArray[3];
        if (StringArray[4].charAt(0) == '*')
        {
            laststate = true;
            State2 = StringArray[4].substring(1);
        }
        else
        {
            laststate = false;
            State2 = StringArray[4];
        }

    }
    
    public String Grammer(LinkedList<String> States)
    {
        if (this.Output == "_")
        {
            return "(" + this.State1 + this.Input2 + this.State2 + ")" + "->" + this.Input1;
        }
        String CFG = "";
        for (String x : States)
        {
        	String str = "";
            for (String y: States)
            {
                str += "(" + this.State1 + this.Input2 + x + ")" + "->" + this.Input1 +
                		"(" + this.State2 + this.Output.substring(0) + y + ")" + "(" + y + this.Output.substring(1) + x + ")";
                str += "|";
            }
            str = str.substring(0, str.length() - 1);
            CFG += str + "\n";
        }
        
        return CFG.substring(0, CFG.length() - 1);
         
    }
}
